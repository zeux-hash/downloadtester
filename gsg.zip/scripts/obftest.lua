shit = print

poop = {
"Hi there",
"whats up",
"yeah I thought so"

}

for i,v in pairs(poop) do
shit(v)

end

